#!/bin/perl
#cours : BIF7101 Bioinformatique des structures
#auteur : Mohamed Amine Remita
#date : 21/03/2016

use strict;
use warnings;

my $USAGE = "\nperl calculer_Xu_triplets.pl fichierEntree Classe fichierSortie\n";

if (scalar @ARGV != 3){die $USAGE;}

my $infile = $ARGV[0];             # RNAfold fasta file
my $class = $ARGV[1];              # Class
my $outFile = $ARGV[2];            # output csv file


my %hairpins = &retrieveFastaSeqStruct ($infile);
my @TRIPLETS = getAllTriplet();

open my $OUT , ">".$outFile or die $!;
# entete
print $OUT "#\"id\",";
for my $triplet (@TRIPLETS){print $OUT "\"$triplet\",";}
print $OUT "\"Class\"\n";

for my $idPrec (keys %hairpins){
  my $sequence = $hairpins{$idPrec}[0];
  my $structure = $hairpins{$idPrec}[1];
  
  my %tripletHash = getXuTriplets($idPrec, $sequence, $structure);
  
  print $OUT "$idPrec,";
  
  for my $triplet (@TRIPLETS){
    if (defined $tripletHash{$triplet}){
      print $OUT $tripletHash{$triplet}.",";
    }else{
      print $OUT "0,";
    }
  }
  
  print $OUT "$class\n";
}

close $OUT;


# Fonctions
####################
#
sub getAllTriplet {
  my @db = ("...", "..(", ".((", "(((", "((.", "(..", "(.(", ".(.");
  my @nd = ("a", "c", "g", "u");
  my @final = ();
  
  foreach my $x (@nd){
    foreach my $z (@db){
      push @final , $x.$z;
    }
  }
  
  return @final; 
}
#
sub getXuTriplets {
  my ($id, $sequence, $struct) = @_;
  my %hash = ();
  
  # # test
  # my $sequence = "CGCUGGUUCAUGCCAACCGCAUUUUGUUGCUGGAAUAACGCCUGCCCAUGGUGUCCAUCUUUCAUCAGAGUCAAUGCAAUGUUUCGGUGUCUGUCUC";  # apPre_53496
  # my $struct   = "((((((..(((((.....(.((((((.((..(((...(((((.......)))))...)))..)).)))))))...)).)))..))))))........";
  
  if (length $sequence != length $struct){ die "Attention la sequence $id n'a pas la meme longueur que la structure secondaire";}
  
  $sequence = lc ($sequence);
  $struct =~ s/\)/\(/g;
  my @seq_tab = split ("", $sequence);
  my @str_tab = split ("", $struct);
  
  for (my $i = 0; $i <= $#seq_tab ; $i++){
    my $before = $str_tab[$i-1];
    my $midlle = $str_tab[$i];
    my $after = $str_tab[$i+1];
    
    # start and ebd of sequence
    unless (defined $before){$before = ".";}
    unless (defined $after){$after = ".";}
    
    my $triplet = $seq_tab[$i].$before.$midlle.$after;
    # print $triplet."\n";
    $hash{$triplet} ++;
  }
  
  return %hash;
}
# This function process a RNAfold output
sub retrieveFastaSeqStruct {
  my %hash = ();
  my ($name, $seq, $struct);
  open my $FAS, $_[0] or die $!;
  
  while (<$FAS>){
    chomp;
    if (/^>/){                                   # nouvelle sequence
      if (defined $name) {                       # traitement de la sequence precedante
        if (!defined $seq) {print STDERR "Error sequence not initialized for $name \n\n";}
        else {
          push @{$hash{$name}}, $seq;
          push @{$hash{$name}}, $struct;
        }
        $name = undef;$seq = undef;$struct = undef;     # initialisation pour la prochaine sequence
      }
      $name = (split /^>/,$_)[1];                       #traitement de la sequence actuelle
    }else{
      if (/[ACGU]+/){$seq = $_;}
      else{$struct = (split /\s+/, $_)[0];}
    }
  }
  push @{$hash{$name}}, $seq;
  push @{$hash{$name}}, $struct;

  close $FAS;
  return %hash;
}
